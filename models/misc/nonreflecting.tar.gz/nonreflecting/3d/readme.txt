This is to test nonreflecting boundary in 3D.

It has 3 parts.

Part 1 is the mesh part. 24x24x24 elements.

Part 10 and part 11 are the material parts.
Part 10 is the material info for water. MAT_NULL+EOS_GRUNEISEN.
Part 11 is the material info for HE. MAT_HE+EOS_JWL.

a layer of solid elements at +x, +y, +z face are set up as non-reflecting ambient elements.


keyword files:

main.k
->  mesh_mmale.k
->  mesh_oldnrf.k
->  mesh_sale.k
